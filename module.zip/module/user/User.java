package org.coral.server.module.user;

import org.coral.server.module.base.UserPo;
import org.springframework.stereotype.Repository;

/**
* @author Jeremy
*/
@Repository
public class User extends UserPo {

	public User() {

	}
	
}
