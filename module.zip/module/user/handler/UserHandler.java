package org.coral.server.module.user.handler;

import org.coral.net.core.annotation.Cmd;
import org.coral.net.core.base.IHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class UserHandler implements IHandler{
	
	private static final Logger log = LoggerFactory.getLogger(UserHandler.class);
	
	@Cmd(id = 0, mustLogin = false)
	public void login() {
		log.info("UserHandler login");
	}

}
