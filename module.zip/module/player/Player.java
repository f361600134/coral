package org.coral.server.module.player;

import org.coral.server.module.base.PlayerPo;
import org.springframework.stereotype.Repository;

@Repository
public class Player extends PlayerPo{

}
