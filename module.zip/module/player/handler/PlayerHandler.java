package org.coral.server.module.player.handler;

import org.coral.net.core.annotation.Cmd;
import org.coral.net.core.base.IHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.protobuf.GeneratedMessageLite;

@Service
public class PlayerHandler implements IHandler{
	
	private static final Logger log = LoggerFactory.getLogger(PlayerHandler.class);
	
	@Cmd(id = 1, mustLogin = false)
	public void login(Object obj, GeneratedMessageLite msg) {
		log.info("PlayerHandler login");
	}

}
